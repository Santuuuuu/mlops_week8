
# Your CI/CD checker code
import mlflow
import mlflow.sklearn
from sklearn.metrics import accuracy_score
from datetime import datetime
import requests

class CICDChecker:
    def __init__(self, tracking_uri="http://34.122.162.121:8100/"):
        self.tracking_uri = tracking_uri
        mlflow.set_tracking_uri(tracking_uri)
        self.client = mlflow.tracking.MlflowClient()
    
    def check_mlflow_connection(self):
        try:
            response = requests.get(self.tracking_uri, timeout=10)
            return response.status_code == 200
        except:
            return False
    
    def check_model_registry_health(self):
        try:
            model = self.client.get_registered_model("iris-classifier")
            return True
        except:
            return False
    
    def check_production_model_quality(self, min_accuracy=0.85):
        try:
            production_models = self.client.get_latest_versions("iris-classifier", stages=["Production"])
            if not production_models:
                return False
            prod_model = production_models[0]
            model = mlflow.sklearn.load_model(prod_model.source)
            iris = load_iris()
            X, y = iris.data, iris.target
            predictions = model.predict(X)
            accuracy = accuracy_score(y, predictions)
            return accuracy >= min_accuracy
        except:
            return False

ci_cd = CICDChecker()
