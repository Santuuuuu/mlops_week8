
# Your model registry code
def manage_model_registry():
    client = mlflow.tracking.MlflowClient()
    model_name = "iris-classifier"
    
    experiment = mlflow.get_experiment_by_name("iris-classification-vertex-ai")
    runs = mlflow.search_runs(experiment_ids=[experiment.experiment_id])
    
    if len(runs) > 0:
        best_run = runs.loc[runs['metrics.test_accuracy'].idxmax()]
        best_run_id = best_run['run_id']
        model_uri = f"runs:/{best_run_id}/model"
        
        try:
            client.get_registered_model(model_name)
        except:
            client.create_registered_model(model_name)
        
        model_version = client.create_model_version(
            name=model_name,
            source=model_uri,
            run_id=best_run_id
        )
        
        client.transition_model_version_stage(
            name=model_name,
            version=model_version.version,
            stage="Production",
            archive_existing_versions=True
        )
        
        return best_run_id, model_version.version

best_run_id, model_version = manage_model_registry()
