
# Your hyperparameter tuning code
import mlflow
import mlflow.sklearn
import pandas as pd
import numpy as np
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score, classification_report, confusion_matrix
import optuna
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

# Your MLFlow setup code
MLFLOW_TRACKING_URI = "http://34.122.162.121:8100/"
mlflow.set_tracking_uri(MLFLOW_TRACKING_URI)
experiment_name = "iris-classification-vertex-ai"
mlflow.set_experiment(experiment_name)

# Your data loading code
def load_and_prepare_data():
    iris = load_iris()
    X = pd.DataFrame(iris.data, columns=iris.feature_names)
    y = pd.Series(iris.target)
    target_names = iris.target_names
    y_named = y.map({i: name for i, name in enumerate(target_names)})
    return X, y, y_named, target_names

X, y, y_named, target_names = load_and_prepare_data()
X_train, X_test, y_train, y_test, y_train_named, y_test_named = train_test_split(
    X, y, y_named, test_size=0.2, random_state=42, stratify=y
)

# Your hyperparameter tuning function
def objective(trial, X_train, y_train):
    params = {
        'n_estimators': trial.suggest_int('n_estimators', 50, 300),
        'max_depth': trial.suggest_int('max_depth', 3, 20),
        'min_samples_split': trial.suggest_int('min_samples_split', 2, 10),
        'min_samples_leaf': trial.suggest_int('min_samples_leaf', 1, 5),
        'max_features': trial.suggest_categorical('max_features', ['sqrt', 'log2', None]),
        'bootstrap': trial.suggest_categorical('bootstrap', [True, False]),
        'criterion': trial.suggest_categorical('criterion', ['gini', 'entropy'])
    }
    model = RandomForestClassifier(random_state=42, **params)
    scores = cross_val_score(model, X_train, y_train, cv=5, scoring='accuracy')
    return np.mean(scores)

def run_hyperparameter_tuning(X_train, y_train, n_trials=20):
    with mlflow.start_run(run_name="hyperparameter_tuning") as parent_run:
        study = optuna.create_study(direction='maximize')
        study.optimize(lambda trial: objective(trial, X_train, y_train), n_trials=n_trials)
        best_params = study.best_params
        best_value = study.best_value
        mlflow.log_params(best_params)
        mlflow.log_metric("best_cv_accuracy", best_value)
        return best_params, best_value, study, parent_run.info.run_id

# Run tuning
best_params, best_cv_score, study, tuning_run_id = run_hyperparameter_tuning(X_train, y_train, n_trials=20)
