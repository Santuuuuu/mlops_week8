
# Your model training and logging code
import mlflow
import mlflow.sklearn
import pandas as pd
from sklearn.metrics import accuracy_score, f1_score, classification_report, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns

def train_and_log_model(X_train, X_test, y_train, y_test, best_params, run_name="final_model"):
    with mlflow.start_run(run_name=run_name) as run:
        model = RandomForestClassifier(random_state=42, **best_params)
        model.fit(X_train, y_train)
        
        y_pred = model.predict(X_test)
        accuracy = accuracy_score(y_test, y_pred)
        f1 = f1_score(y_test, y_pred, average='weighted')
        
        mlflow.log_params(best_params)
        mlflow.log_metric("test_accuracy", accuracy)
        mlflow.log_metric("test_f1_score", f1)
        
        mlflow.sklearn.log_model(
            model, 
            "model",
            registered_model_name="iris-classifier"
        )
        
        return model, accuracy, f1, run.info.run_id

# Train final model
final_model, test_accuracy, test_f1, model_run_id = train_and_log_model(
    X_train, X_test, y_train, y_test, best_params, "optimized_model"
)
