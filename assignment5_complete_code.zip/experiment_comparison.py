
# Your experiment comparison code
def create_comparison_experiments():
    comparison_configs = [
        {
            "name": "baseline_default",
            "params": {
                "n_estimators": 100,
                "max_depth": None,
                "min_samples_split": 2,
                "min_samples_leaf": 1,
                "max_features": "sqrt",
                "bootstrap": True,
                "criterion": "gini"
            }
        },
        {
            "name": "conservative_model", 
            "params": {
                "n_estimators": 50,
                "max_depth": 10,
                "min_samples_split": 5,
                "min_samples_leaf": 3,
                "max_features": "log2",
                "bootstrap": True,
                "criterion": "gini"
            }
        }
    ]
    
    results = []
    for config in comparison_configs:
        with mlflow.start_run(run_name=config['name']):
            model = RandomForestClassifier(random_state=42, **config['params'])
            model.fit(X_train, y_train)
            y_pred = model.predict(X_test)
            accuracy = accuracy_score(y_test, y_pred)
            mlflow.log_params(config['params'])
            mlflow.log_metric("test_accuracy", accuracy)
            mlflow.sklearn.log_model(model, "model")
            results.append({"experiment": config['name'], "accuracy": accuracy})
    
    return results

comparison_results = create_comparison_experiments()
