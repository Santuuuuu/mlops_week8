# Assignment 3: Feast Feature Store
This submission contains ONLY the Feast assignment (Assignment 3).

## Contents:
- `notebook/feast_assignment.ipynb` - Notebook cells related to Feast only
- `feature_store/` - Feast configuration and feature definitions
